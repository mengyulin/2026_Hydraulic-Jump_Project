"""Small hydraulic/format checks. Full P0 integrations are separate."""
import json
from pathlib import Path
import sys
import tempfile
import unittest
import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from case_tools import load_case,resolve,standard_step,bed_z,ss
from hec_tools import export_project,check_project,compare_export
from postprocess import crossings,summarize


class TeachingChecks(unittest.TestCase):
    def test_boundary_physics_and_family_controls(self):
        base=load_case()
        for i in range(1,6):
            for suffix in 'LH':
                c=load_case(f'P{i}{suffix}');flow=ss.Flow(c['q_m2s'],c['width_m'],c['n'])
                self.assertAlmostEqual(flow.sf(c['hin_m']),c['S1'],places=10)
                self.assertGreater(c['Fr_in'],1);self.assertLess(c['Fr_out'],1)
                self.assertEqual(bed_z(c['length_m'],c),c['z_out_m'])
                if i!=2:self.assertEqual(c['hout_m'],base['hout_m'])
                if i not in (1,5):self.assertEqual(c['hin_m'],base['hin_m'])
        self.assertGreater(load_case('P5L')['Fr_in'],base['Fr_in'])

    def test_no_silent_unsupported_core_parameters(self):
        for key,value in [('width_m',1.),('g_m_s2',10.),('Cc',.1),('n',float('nan')),('transition_length_m',0),('hout_m',.01)]:
            with self.assertRaises(ValueError):resolve(load_case()|{key:value})

    def test_all_eleven_have_positive_energy_and_conjugate_match(self):
        for name in ['P0']+[f'P{i}{s}' for i in range(1,6) for s in 'LH']:
            result,rows=standard_step(load_case(name),.125);j=result['summary']['jumps'][0]
            self.assertEqual(rows[0][0],0);self.assertEqual(rows[-1][0],30)
            self.assertTrue(all(h>0 for _,_,h in rows));self.assertGreater(j['energy_loss_m'],0)
            ratio=.5*(np.sqrt(1+8*j['Fr1']**2)-1)
            self.assertAlmostEqual(j['y2_m']/j['y1_m'],ratio,places=10)

    def test_multiple_crossings_are_not_silently_unique(self):
        x=np.arange(7,dtype=float);h=np.array([.05,.1,.2,.08,.2,.18,.17])
        self.assertEqual(len(crossings(x,h,.125)),2)
        s=summarize(x,h,load_case(),dict(x_m=2.,y1_m=.05,y2_m=.2),'b')
        self.assertIsNone(s['x50_unique_m']);self.assertIsNotNone(s['first_x50_supplementary_m'])

    def test_hec_round_trip_and_reject_mismatched_output(self):
        with tempfile.TemporaryDirectory() as tmp:
            out=export_project(load_case(),Path(tmp)/'P0')
            for project in out.glob('*/*.prj'):
                self.assertTrue(check_project(project)['static_check_passed'])
            bad=Path(tmp)/'bad.csv';bad.write_text('river_station,water_surface_m,Fr,Q_m3_s\n0,.167,0.5,.0541379\n')
            with self.assertRaises(ValueError):compare_export(out/'dx0p5',bad,Path(tmp)/'rejected')


if __name__=='__main__':unittest.main()
